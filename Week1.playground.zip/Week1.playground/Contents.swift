

import Foundation

let appName: String = "Swift Practice"
var version: Double = 1.0
var isLearning = true

let year = 2025
let message = "Welcome to \(appName) v\(version) — Year: \(year)"
print(message)

// Type inference vs. explicit types
let pi = 3.14159        // inferred Double
let luckyNumber: Int = 7

// Arithmetic and compound assignment
var score = 10
score += 5
score *= 2
print("Score is \(score)")  // 30

// Strings
let greeting = "Hello, " + "world!"
print(greeting.uppercased())
print("Has prefix \"He\"? ->", greeting.hasPrefix("He"))

// Booleans
if isLearning {
    print("You're on track. ")
} else {
    print("Let's get started!")
}

