

import Foundation

// Arrays
var todo: [String] = ["Read", "Code", "Exercise"]
todo.append("Sleep")
print("Todo count:", todo.count)
for (i, task) in todo.enumerated() {
    print("\(i + 1). \(task)")
}

// Sets
let setA: Set<Int> = [1,2,3,3,2,1]
let setB: Set<Int> = [3,4,5]
print("SetA:", setA.sorted())
print("Union:", setA.union(setB).sorted())
print("Intersection:", setA.intersection(setB).sorted())

// Dictionaries
var user: [String: Any] = [
    "name": "Nayan",
    "year": 2025,
    "isStudent": true
]
user["school"] = "Georgia Tech"
if let school = user["school"] as? String {
    print("School:", school)
}


for n in 1...10 where n % 2 == 0 {
    print("Even:", n)
}
