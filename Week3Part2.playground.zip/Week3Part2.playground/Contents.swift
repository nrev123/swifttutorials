

import Foundation

let numbers = [1,2,3,4,5,6]
let squares = numbers.map { $0 * $0 }
let evens = numbers.filter { $0 % 2 == 0 }
let sum = numbers.reduce(0, +)
print("squares:", squares, "evens:", evens, "sum:", sum)

// Sort with custom closure
let words = ["Swift", "is", "fast", "and", "fun"]
let sorted = words.sorted { a, b in a.count < b.count }
print(sorted)

// Escaping closure demo
var pending: [() -> Void] = []
func later(_ work: @escaping () -> Void) {
    pending.append(work)
}

later { print("This runs later 1") }
later { print("This runs later 2") }

// Execute queued work
pending.forEach { $0() }

