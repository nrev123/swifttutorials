// Day 3 — Control flow: if/else, switch, ranges, pattern matching

import Foundation

let tempF = 73
if tempF >= 90 {
    print("Hot")
} else if tempF >= 60 {
    print("Pleasant")
} else {
    print("Cold")
}

let coord = (x: 0, y: -2)
switch coord {
case (0, 0):
    print("At origin")
case (0, let y):
    print("On Y-axis at y=\(y)")
case (let x, 0):
    print("On X-axis at x=\(x)")
case (-2...2, -2...2):
    print("Near origin square")
default:
    print("Somewhere else")
}

// fallthrough & value binding
let grade = 87
switch grade {
case 90...100:
    print("A")
case 80..<90:
    print("B")
case 70..<80:
    print("C")
default:
    print("Keep studying")
}
