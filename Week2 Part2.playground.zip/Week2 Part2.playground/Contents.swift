// Day 4 — Functions: parameters, external names, defaults, tuples, inout

import Foundation

func greet(_ name: String = "stranger", enthusiastically: Bool = false) -> String {
    let base = "Hello, \(name)"
    return enthusiastically ? base + "!!!" : base + "."
}

print(greet("Nayan", enthusiastically: true))
print(greet())

func minMax(of numbers: [Int]) -> (min: Int, max: Int)? {
    guard let first = numbers.first else { return nil }
    var (mn, mx) = (first, first)
    for n in numbers.drop(1) {
        mn = Swift.min(mn, n)
        mx = Swift.max(mx, n)
    }
    return (mn, mx)
}

if let result = minMax(of: [6,1,9,4,3]) {
    print("min=\(result.min), max=\(result.max)")
}

// inout
func increment(_ x: inout Int, by amount: Int = 1) { x += amount }
var counter = 0
increment(&counter, by: 3)
print("counter =", counter)
