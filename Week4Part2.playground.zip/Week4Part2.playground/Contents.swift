

import Foundation

protocol Describable {
    var summary: String { get }
    func describe()
}

struct Book: Describable, Codable, Equatable {
    let title: String
    let author: String
    var summary: String { "\(title) by \(author)" }
    func describe() { print(summary) }
}

extension Describable {
    func shout() { print(summary.uppercased()) }
}

let b = Book(title: "Hacking with Swift", author: "Paul Hudson")
b.describe()
b.shout()

// Codable
if let data = try? JSONEncoder().encode(b),
   let json = String(data: data, encoding: .utf8) {
    print("JSON:", json)
    if let decoded = try? JSONDecoder().decode(Book.self, from: data) {
        print("Decoded equals original? ->", decoded == b)
    }
}

