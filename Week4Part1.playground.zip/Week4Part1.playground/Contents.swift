

import Foundation

struct Point {
    var x: Double
    var y: Double
    mutating func move(dx: Double, dy: Double) {
        x += dx; y += dy
    }
}

class Counter {
    var value: Int
    init(_ value: Int = 0) { self.value = value }
    func inc() { value += 1 }
    deinit { print("Counter deinitialized") }
}

var p = Point(x: 0, y: 0)
p.move(dx: 1, dy: -2)
print("Point:", p)

do {
    let c = Counter(10)
    c.inc()
    print("Counter:", c.value)
} // deinit prints when scope ends

