

import Foundation

// Optionals
var nickname: String? = nil
nickname = "Nayan"
if let nick = nickname {
    print("Nickname is", nick)
}

// guard let
func loadInt(from text: String) -> Int? {
    guard let value = Int(text) else {
        print("Not an Int:", text)
        return nil
    }
    return value
}
print(loadInt(from: "42") ?? -1)

// Optional chaining
struct Profile { var bio: String? }
struct User { var profile: Profile? }
let u = User(profile: Profile(bio: "iOS learner"))
print(u.profile?.bio?.capitalized ?? "No bio")

// Error handling
enum FileError: Error { case notFound, unreadable }

func readFile(named: String) throws -> String {
    if named == "missing.txt" { throw FileError.notFound }
    if named == "gibberish.txt" { throw FileError.unreadable }
    return "Hello from \(named)"
}

do {
    let contents = try readFile(named: "hello.txt")
    print(contents)
} catch FileError.notFound {
    print("File not found")
} catch {
    print("Other error:", error)
}

